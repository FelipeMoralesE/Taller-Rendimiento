#include "funciones.h"  // Incluye el archivo que contiene las declaraciones de las funciones
#include <stdlib.h>      // Incluye la biblioteca estándar para utilizar la función srand48() y las macros de gestión de memoria
#include <stdio.h>       // Incluye la biblioteca estándar para entrada y salida 
#include <time.h>        // Incluye la biblioteca estándar para la gestión de tiempo
#include <pthread.h>     // Incluye la biblioteca para manejar hilos (threads)

// Declaración de variables globales
double *mA, *mB, *mC;         // Punteros a matrices
pthread_mutex_t MM_mutex;     // Mutex para control de acceso a matrices
struct timeval start, stop;   // Variables para medir el tiempo

// Función para llenar las matrices con valores
void llenar_matriz(int SZ) {
    // Establece la semilla del generador de números aleatorios basada en el tiempo actual
    srand48(time(NULL));

    // Llena las matrices con valores predefinidos
    for(int i = 0; i < SZ*SZ; i++){
        mA[i] = 1.1*i;
        mB[i] = 2.2*i;
        mC[i] = 0;
    }
}

// Función para imprimir una matriz
void print_matrix(int sz, double *matriz) {
    // Imprime la matriz si el tamaño no es muy grande
    if(sz < 12) {
        for(int i = 0; i < sz*sz; i++) {
            if(i%sz==0) printf("\n");     // Imprime una nueva línea al inicio de cada fila
            printf(" %.3f ", matriz[i]);  // Imprime cada elemento de la matriz con tres decimales
        }
        printf("\n>-------------------->\n");  // Imprime un separador después de la matriz
    }
}

// Función para iniciar la medición del tiempo
void inicial_tiempo() {
    gettimeofday(&start, NULL);  // Obtiene el tiempo actual
}

// Función para finalizar la medición del tiempo y mostrar el resultado
void final_tiempo() {
    gettimeofday(&stop, NULL);                // Obtiene el tiempo actual
    stop.tv_sec -= start.tv_sec;               // Calcula la diferencia en segundos
    printf("\n:-> %9.0f Âµs\n", (double) (stop.tv_sec*1000000 + stop.tv_usec));  // Imprime el tiempo transcurrido en microsegundos
}

// Función ejecutada por cada hilo para realizar la multiplicación de matrices
void *mult_thread(void *variables) {
    struct parametros *data = (struct parametros *)variables;  // Obtiene los parámetros pasados al hilo

    int idH = data->idH;    // Identificador del hilo
    int nH  = data->nH;     // Número total de hilos
    int N   = data->N;      // Tamaño de las matrices
    int ini = (N/nH)*idH;   // Índice de inicio de la sección a procesar por el hilo
    int fin = (N/nH)*(idH+1);  // Índice de fin de la sección a procesar por el hilo

    // Realiza la multiplicación de matrices para la sección asignada al hilo
    for (int i = ini; i < fin; i++) {
        for (int j = 0; j < N; j++) {
            double *pA, *pB, sumaTemp = 0.0;
            pA = mA + (i*N);
            pB = mB + j;
            for (int k = 0; k < N; k++, pA++, pB+=N) {
                sumaTemp += (*pA * *pB);  // Realiza la multiplicación y suma de elementos
            }
            mC[i*N+j] = sumaTemp;  // Almacena el resultado en la matriz resultante
        }
    }

    pthread_mutex_lock (&MM_mutex);   // Bloquea el mutex para realizar operaciones críticas
    pthread_mutex_unlock (&MM_mutex); // Desbloquea el mutex después de realizar operaciones críticas

    pthread_exit(NULL);  // Termina el hilo
}