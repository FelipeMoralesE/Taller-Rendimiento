// funciones.h
// Este archivo contiene la declaración de las funciones utilizadas en el programa.
// Define una serie de funciones para operar con matrices, medir el tiempo de ejecución
// y realizar multiplicación de matrices en un entorno de hilos.

#ifndef FUNCIONES_H
#define FUNCIONES_H

#include <pthread.h>
#include <sys/time.h>

// Declaración de variables globales
extern pthread_mutex_t MM_mutex; // Mutex para sincronización de hilos
extern struct timeval start, stop; // Variables para medir el tiempo de ejecución

// Estructura para pasar parámetros a la función de los hilos
struct parametros{
  int nH; // Número total de hilos
  int idH; // Identificador del hilo actual
  int N; // Tamaño de la matriz
};

// Declaración de funciones
void llenar_matriz(int SZ); // Función para llenar una matriz con valores aleatorios
void print_matrix(int sz, double *matriz); // Función para imprimir una matriz
void inicial_tiempo(); // Función para iniciar el contador de tiempo
void final_tiempo(); // Función para detener el contador de tiempo
void *mult_thread(void *variables); // Función ejecutada por cada hilo para la multiplicación de matrices

#endif

