#include "funciones.h"  // Incluye el archivo que contiene las declaraciones de las funciones
#include <stdlib.h>      // Incluye la biblioteca estándar para utilizar la función srand48() y las macros de gestión de memoria
#include <stdio.h>       // Incluye la biblioteca estándar para entrada y salida 
#include <time.h>        // Incluye la biblioteca estándar para la gestión de tiempo
#include <pthread.h>     // Incluye la biblioteca para manejar hilos (threads)
#include <unistd.h>
#include <time.h>
#include <sys/time.h>

// Se define el tamaño de un bloque de memoria utilizado para almacenar matrices
#define DATA_SIZE (1024*1024*64*3)
// Se define el arreglo estático de tamaño DATA_SIZE, utilizado para almacenar las matrices
static double MEM_CHUNK[DATA_SIZE];
// Se declaran los punteros a las matrices que se van a multiplicar
extern double *mA, *mB, *mC;
// Se declara el mutex utilizado para sincronizar el acceso a las matrices
extern pthread_mutex_t MM_mutex;
// Se declaran las variables para almacenar el tiempo de inicio y final de la ejecución
extern struct timeval start, stop;

int main(int argc, char *argv[]) {
    if (argc < 2) {
        // Se hace la verificación para que se proporcionen suficientes argumentos en la línea de comandos
        printf("Ingreso de argumentos \n $./ejecutable tamMatriz numHilos\n");
        return -1;
    }

    // Se declara el tamaño de la matriz cuadrada a ser multiplicada
    int SZ = atoi(argv[1]);
    // Se declara el número de hilos (threads) a utilizar
    int n_threads = atoi(argv[2]);

    // Se declara el arreglo de identificadores del hilo
    pthread_t p[n_threads];
    // Representa los atributos del hilo para el cálculo de la multiplicación de matrices
    pthread_attr_t atrMM;

    // Se asignan punteros a diferentes bloques de memoria en MEM_CHUNK para almacenar las matrices.
    mA = MEM_CHUNK;
    mB = mA + SZ*SZ;
    mC = mB + SZ*SZ;

    // Se llena la matriz y se inicializan
    llenar_matriz(SZ);
    print_matrix(SZ, mA);
    print_matrix(SZ, mB);

    // Se inicializa la medición del tiempo
    inicial_tiempo();

    // Se inicializa el mutex y los atributos de los hilos
    pthread_mutex_init(&MM_mutex, NULL);
    pthread_attr_init(&atrMM);
    pthread_attr_setdetachstate(&atrMM, PTHREAD_CREATE_JOINABLE);

    // Se crean los hilos para la multiplicación de matrices
    for (int j=0; j<n_threads; j++) {
        struct parametros *datos = (struct parametros *) malloc(sizeof(struct parametros));
        datos->idH = j;
        datos->nH  = n_threads;
        datos->N   = SZ;
        pthread_create(&p[j], &atrMM, mult_thread, (void *)datos);
    }

    // Se esperan a que los hilos terminen
    for (int j=0; j<n_threads; j++)
        pthread_join(p[j], NULL);

    // Se imprime el tiempo final
    final_tiempo();

    // Se imprime la matriz final
    print_matrix(SZ, mC);

    // Se liberan los hilos y el mutex
    pthread_attr_destroy(&atrMM);
    pthread_mutex_destroy(&MM_mutex);
    pthread_exit(NULL);
}